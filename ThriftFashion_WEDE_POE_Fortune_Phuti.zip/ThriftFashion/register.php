// Page Navigation
<div>
<a href="login.php">Login</a> |
<a href="register.php">Register</a> |
<a href="adminLogin.php">Admin Login</a>
</div>


<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>

<h2>Register</h2>

<form method="POST" action="registerProcess.php">
    Name: <input type="text" name="name" required><br><br>
    Email: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    Phone: <input type="text" name="phone"><br><br>
    Address: <input type="text" name="address"><br><br>

    <button type="submit">Register</button>
</form>

</body>
</html>
