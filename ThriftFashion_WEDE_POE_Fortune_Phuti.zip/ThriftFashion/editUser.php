// Page Navigation
<div>
<a href="manageUsers.php">Back To Users</a> |
<a href="adminDashboard.php">Dashboard</a>
</div>

<?php
include 'DBConn.php';

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM User WHERE UserID=$id")->fetch_assoc();

if ($_POST) {
    $name = $_POST['name'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    $conn->query("UPDATE User 
                  SET FullName='$name', Role='$role', AccountStatus='$status'
                  WHERE UserID=$id");

    header("Location: adminDashboard.php");
}
?>

<form method="POST">
    Name: <input type="text" name="name" value="<?php echo $user['FullName']; ?>"><br>

    Role:
    <select name="role">
        <option <?php if($user['Role']=="Buyer") echo "selected"; ?>>Buyer</option>
        <option <?php if($user['Role']=="Seller") echo "selected"; ?>>Seller</option>
        <option <?php if($user['Role']=="Admin") echo "selected"; ?>>Admin</option>
    </select><br>

    Status:
    <select name="status">
        <option>Active</option>
        <option>Suspended</option>
        <option>Banned</option>
    </select><br>

    <button type="submit">Update</button>
</form>
