
<?php
session_start();
include 'DBConn.php';

if(isset($_GET['id']))
{
    $sellerID = $_GET['id'];
}
else
{
    die("Seller not found.");
}

?>
//Seller Review Form
<h3>Rate This Seller (Optional)</h3>

<form method="POST"
      action="submitSellerReview.php">

    <input type="hidden"
           name="sellerID"
           value="<?php echo $sellerID; ?>">

           <h3>Seller Reviews</h3>
           
<?php
$sellerReviews =
$conn->query(
"SELECT *
 FROM SellerReview
 WHERE SellerID='$sellerID'
 ORDER BY ReviewDate DESC"
);
while($row =
$sellerReviews->fetch_assoc())
{
echo "<div>";
echo "<strong>";
echo $row['Rating'];
echo "/5 Stars";
echo "</strong><br>";
echo $row['Review'];
echo "<hr>";
echo "</div>";
}
?>

    Rating:
    <select name="rating">
        <option value="1">1 Star</option>
        <option value="2">2 Stars</option>
        <option value="3">3 Stars</option>
        <option value="4">4 Stars</option>
        <option value="5">5 Stars</option>
    </select>
    <br><br>
    Review:
    <textarea name="review"></textarea>
    <br><br>
    <button type="submit">
        Submit Seller Review
    </button>

    <?php

// Calculate seller average rating
$result =
$conn->query(

"SELECT AVG(Rating) AS AverageRating
 FROM SellerReview
 WHERE SellerID='$sellerID'"
);

$ratingData =
$result->fetch_assoc();
echo "<h3>";
echo "Average Seller Rating: ";
echo round($ratingData['AverageRating'],1);
echo "/5 Stars";
echo "</h3>";
?>
</form>