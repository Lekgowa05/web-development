<?php
session_start();
include 'DBConn.php';

//  Ensure only admins can access this page
if(!isset($_SESSION['admin']))
{
    header("Location: adminLogin.php");
    exit();
}

$message = "";
if(isset($_POST['submit']))
{
    $productName = $_POST['productName'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $brand = $_POST['brand'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];
    $gender = $_POST['gender'];

    //  Insert product
    $sql = "INSERT INTO Product
(
ProductName,
Description,
Price,
Category,
Gender,
Brand,
Size,
Quantity
)
VALUES
(
'$productName',
'$description',
'$price',
'$category',
'$gender',
'$brand',
'$size',
'$quantity'
)";

    $conn->query($sql);
    $message = "Clothing item added successfully.";
}
?>
<div>
<a href="manageProducts.php">Back To Products</a> |
<a href="adminDashboard.php">Dashboard</a> |
<a href="logout.php">Logout</a>
</div>

<h2>Add Clothing Item</h2>

<?php if(!empty($message)) { echo "<p style='color:green;'>$message</p>"; } ?>

<form method="POST">

    Product Name:
    <input type="text" name="productName" required>
    <br><br>
    Description:
    <textarea name="description"></textarea>
    <br><br>
    Price:
    <input type="number" step="0.01" name="price" required>

    <br><br>
    Category:
    <input type="text" name="category">
    <br><br>
    Brand:
    <input type="text" name="brand">
    <br><br>
    Size:
    <input type="text" name="size">
    <br><br>
    Quantity:
    <input type="number" name="quantity">
    <br><br>
    Gender:
    <select name="gender">
        <option value="Men">Men</option>
        <option value="Women">Women</option>
        <option value="Unisex">Unisex</option>
    </select>
    <br><br>
    <button type="submit" name="submit">
        Add Clothing
    </button>
</form>
