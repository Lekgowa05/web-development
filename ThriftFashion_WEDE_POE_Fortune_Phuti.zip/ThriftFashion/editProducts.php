<div>
<a href="manageProducts.php">Back To Products</a> |
<a href="adminDashboard.php">Dashboard</a>
</div>

<?php

session_start();

include 'DBConn.php';

$id = $_GET['id'];

$product = $conn->query(
"SELECT * FROM Product
 WHERE ProductID=$id")
->fetch_assoc();

if(isset($_POST['update']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    // update Product 
    $conn->query(
    "UPDATE Product

    SET ProductName='$name',
        Price='$price',
        Quantity='$quantity'
    WHERE ProductID=$id");

    header("Location: manageProducts.php");
    exit();
}

?>

<form method="POST">

Name:
<input type="text"
name="name"
value="<?php echo $product['ProductName']; ?>">

<br><br>

Price:
<input type="number"
step="0.01"
name="price"
value="<?php echo $product['Price']; ?>">

<br><br>

Quantity:
<input type="number"
name="quantity"
value="<?php echo $product['Quantity']; ?>">

<br><br>

<button type="submit"
name="update">

Update Product

</button>

</form>