
<div>
<a href="dashboard.php">Dashboard</a> |
<a href="products.php">Products</a> |
<a href="inbox.php">Messages</a> |
<a href="logout.php">Logout</a>
</div>

<?php

session_start();

include 'DBConn.php';

//Ensure user is logged in
if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Sell Clothing</title>
</head>
<body>
<div>
<a href="dashboard.php">Dashboard</a> |
<a href="products.php">Shop</a> |
<a href="logout.php">Logout</a>
</div>
<hr>
<h2>Submit Clothing For Sale</h2>
<form
method="POST"
action="submitClothing.php"
enctype="multipart/form-data">

Product Name:

<input
type="text"
name="productName"
required>
<br><br>

Brand:

<input
type="text"
name="brand"
required>
<br><br>

Description:

<textarea
name="description"
required>
</textarea>
<br><br>

Size:

<input
type="text"
name="size"
required>
<br><br>

Price:

<input
type="number"
step="0.01"
name="price"
required>
<br><br>

Image:

<input
type="file"
name="image"
accept="image/*"
required>
<br><br>

<button type="submit">

Submit Request

</button>
</form>
</body>
</html>