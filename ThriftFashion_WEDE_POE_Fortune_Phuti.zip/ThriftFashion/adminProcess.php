// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>


<?php
session_start();
include 'DBConn.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM User WHERE Email='$email' AND Role='Admin'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();

    if (md5($password) == $admin['Password']) {
        $_SESSION['admin'] = $admin;
        header("Location: adminDashboard.php");
    } else {
        $_SESSION['admin_error'] = "Incorrect password";
        header("Location: adminLogin.php");
    }
} else {
    $_SESSION['admin_error'] = "Not an admin account";
    header("Location: adminLogin.php");
}

$conn->close();
?>
