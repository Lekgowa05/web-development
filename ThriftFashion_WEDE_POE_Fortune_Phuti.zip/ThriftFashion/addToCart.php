<?php

session_start();

$productID = $_POST['productID'];
//Create shopping cart if it doesn't exist
if(!isset($_SESSION['cart']))
{
    $_SESSION['cart'] = [];
}
//Increase quantity if item already exists

if(isset($_SESSION['cart'][$productID]))
{
    $_SESSION['cart'][$productID]++;
}
else
{   
   // First item starts with quantity 1
    $_SESSION['cart'][$productID] = 1;
}
// Return customer to product page
header("Location: products.php");
exit();

?>