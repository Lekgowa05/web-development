<?php
session_start();
include 'DBConn.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <a href="products.php"> Continue Shopping</a>
</div>

<h2>Your Shopping Cart</h2>

<?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) { 
    $total = 0; 
?>
    <form method="POST" action="updateCart.php" style="max-width: 100%; padding:0; border:none; box-shadow:none; background:none;">
        <table>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>
            <?php
            foreach($_SESSION['cart'] as $productID => $quantity) {
                $productResult = $conn->query("SELECT * FROM Product WHERE ProductID=$productID");
                $product = $productResult->fetch_assoc();
                $subtotal = $product['Price'] * $quantity;
                $total += $subtotal;
            ?>
            <tr>
                <td style="font-weight: 600;"><?php echo $product['ProductName']; ?></td>
                <td>R <?php echo number_format($product['Price'], 2); ?></td>
                <td>
                    <input type="number" name="quantity[<?php echo $productID; ?>]" value="<?php echo $quantity; ?>" min="1" style="width: 80px; margin:0;">
                </td>
                <td style="font-weight: 600;">R <?php echo number_format($subtotal, 2); ?></td>
                <td>
                    <a href="removeFromCart.php?id=<?php echo $productID; ?>" style="color: var(--danger); text-decoration: none; font-weight: 600;"> Remove</a>
                </td>
            </tr>
            <?php } ?>
        </table>
        
        <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
            <button type="submit" style="width: auto; background-color: var(--text-light)"> Update Cart</button>
            <h3 style="margin: 0;">Total: <span style="color: var(--success);">R <?php echo number_format($total, 2); ?></span></h3>
        </div>
    </form>

    <div style="margin-top: 30px; max-width: 200px;">
        <a href="checkout.php" class="btn" style="display: block; text-align: center; text-decoration: none; box-sizing: border-box;">Proceed To Checkout </a>
    </div>
<?php } else { ?>
    <div style="background: white; padding: 40px; text-align: center; border-radius: 12px; border: 1px solid var(--border);">
        <p style="color: var(--text-light); font-size: 18px;">Your shopping cart is empty.</p>
        <a href="products.php" style="color: var(--primary); font-weight:600;">Browse clothing items here</a>
    </div>
<?php } ?>

</body>
</html>
