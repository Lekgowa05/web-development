// Page Navigation
<div>
<a href="login.php">Customer Login</a> |
<a href="register.php">Register</a> |
<a href="adminLogin.php">Admin Login</a>
</div>

<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
</head>
<body>

<h2>Admin Login</h2>

<form method="POST" action="adminProcess.php">
    Email: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
</form>

<p style="color:red;">
<?php
if (isset($_SESSION['admin_error'])) {
    echo $_SESSION['admin_error'];
    unset($_SESSION['admin_error']);
}
?>
</p>

</body>
</html>
