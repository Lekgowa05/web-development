// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>


<?php
include 'DBConn.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = md5($_POST['password']); // Hash password
$phone = $_POST['phone'];
$address = $_POST['address'];
//checking if email is not duplicated
$checkEmail = $conn->query(
"SELECT * FROM User WHERE Email='$email'");

if($checkEmail->num_rows > 0)
{
    die("Email already exists");
}

$sql = "INSERT INTO User 
(FullName, Email, Password, PhoneNumber, Address, Role, AccountStatus)
VALUES 
('$name', '$email', '$password', '$phone', '$address', 'Buyer', 'Suspended')";

if ($conn->query($sql)) {
    echo "Registered successfully. Await admin approval.";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
