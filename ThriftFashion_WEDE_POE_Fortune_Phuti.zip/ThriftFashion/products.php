<?php
session_start();
include 'DBConn.php'; 

$sql = "SELECT * FROM Product WHERE Status='Available'";

if(!empty($_GET['gender'])) {
    $gender = $_GET['gender'];
    $sql .= " AND Gender='$gender'";
}
if(!empty($_GET['size'])) {
    $size = $_GET['size'];
    $sql .= " AND Size='$size'";
}
if(!empty($_GET['category'])) {
    $category = $_GET['category'];
    $sql .= " AND Category='$category'";
}

if(isset($_GET['sort'])) {
    switch($_GET['sort']) {
        case 'date_desc':  $sql .= " ORDER BY DateAdded DESC"; break;
        case 'date_asc':   $sql .= " ORDER BY DateAdded ASC"; break;
        case 'price_asc':  $sql .= " ORDER BY Price ASC"; break;
        case 'price_desc': $sql .= " ORDER BY Price DESC"; break;
    }
}
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Browse Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <a href="dashboard.php">Dashboard</a>
    <a href="products.php" style="color: var(--primary);">Products</a>
    <a href="cart.php">View Cart</a>
    <a href="sellClothing.php">Sell Clothing</a>
    <a href="logout.php">Logout</a>
</div>

<h2>Available Clothing Items</h2>

<form method="GET" style="max-width: 100%; margin-bottom: 30px;">
    <h3>Filter & Sort</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
        <div>
            Gender:
            <select name="gender">
                <option value="">All</option>
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                <option value="Unisex">Unisex</option>
            </select>
        </div>
        <div>
            Size:
            <select name="size">
                <option value="">All</option>
                <option value="XS">XS</option>
                <option value="S">S</option>
                <option value="M">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
            </select>
        </div>
        <div>
            Category:
            <select name="category">
                <option value="">All</option>
                <option value="Shirts">Shirts</option>
                <option value="Pants">Pants</option>
                <option value="Dresses">Dresses</option>
                <option value="Jackets">Jackets</option>
                <option value="Shoes">Shoes</option>
                <option value="Accessories">Accessories</option>
            </select>
        </div>
        <div>
            Sort By:
            <select name="sort">
                <option value="">Default</option>
                <option value="date_desc">Newest First</option>
                <option value="date_asc">Oldest First</option>
                <option value="price_asc">Price Low to High</option>
                <option value="price_desc">Price High to Low</option>
            </select>
        </div>
    </div>
    <button type="submit" style="width: auto; margin-top: 10px;">Apply Filters</button>
</form>

<div class="card-grid">
    <?php while($product = $result->fetch_assoc()) { ?>
        <div class="product-card">
            <div>
                <h3 style="margin-top:0; color: var(--primary);"><?php echo $product['ProductName']; ?></h3>
                <p style="color: var(--text-light); font-size: 14px;"><?php echo $product['Description']; ?></p>
            </div>
            <div>
                <p style="font-size: 18px; font-weight: bold; margin: 10px 0;">R <?php echo number_format($product['Price'], 2); ?></p>
                <form method="POST" action="addToCart.php" style="padding:0; border:none; box-shadow:none; background:none;">
                    <input type="hidden" name="productID" value="<?php echo $product['ProductID']; ?>">
                    <button type="submit">Add To Cart</button>
                </form>
            </div>
        </div>
    <?php } ?>
</div>

</body>
</html>
