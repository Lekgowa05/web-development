//Navigation
<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="manageUsers.php">Manage Users</a> |
<a href="manageProducts.php">Manage Products</a> |
<a href="reviewRequests.php">Seller Requests</a> |
<a href="adminMessage.php">Messages</a> |
<a href="verifyOrder.php">Verify Orders</a> |
<a href="logout.php">Logout</a>
</div>

<hr>

<hr>

<?php
session_start();
include 'DBConn.php';

if (!isset($_SESSION['admin'])) {
    header("Location: adminLogin.php");
    exit();
}

// Fetch all users
$result = $conn->query("SELECT * FROM User");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>

<h2>Admin Dashboard</h2>

<a href="addUser.php">Add New User</a><br><br>

<table border="1">
<tr>
    <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?php echo $row['UserID']; ?></td>
    <td><?php echo $row['FullName']; ?></td>
    <td><?php echo $row['Email']; ?></td>
    <td><?php echo $row['Role']; ?></td>
    <td><?php echo $row['AccountStatus']; ?></td>
    <td>
        <a href="editUser.php?id=<?php echo $row['UserID']; ?>">Edit</a> |
        <a href="deleteUser.php?id=<?php echo $row['UserID']; ?>">Delete</a>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>
