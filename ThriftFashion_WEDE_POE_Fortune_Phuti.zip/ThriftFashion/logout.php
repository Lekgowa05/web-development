// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>

<?php

session_start();

session_unset();
session_destroy();

header("Location: login.php");
exit();

?>
