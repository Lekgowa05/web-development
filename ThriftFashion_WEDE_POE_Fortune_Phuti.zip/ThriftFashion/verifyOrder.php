<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="adminMessage.php">Messages</a> |
<a href="logout.php">Logout</a>
</div>

<?php
session_start();
include 'DBConn.php';
if(isset($_POST['verify']))
{
    $buyerID =
    $_POST['buyerID'];

    $sellerID =
    $_POST['sellerID'];

    $productID =
    $_POST['productID'];

    $adminID =
    $_SESSION['admin']['UserID'];

    $condition =
    $_POST['condition'];

    $delivery =
    $_POST['delivery'];

    $notes =
    $_POST['notes'];

    $conn->query(
    "INSERT INTO OrderVerification
    (
        BuyerID,
        SellerID,
        ProductID,
        AdminID,
        ConditionVerified,
        DeliveryVerified,
        Notes
    )
    VALUES
    (
        '$buyerID',
        '$sellerID',
        '$productID',
        '$adminID',
        '$condition',
        '$delivery',
        '$notes'
    )");
    echo "the Verification is recorded.";
}
?>