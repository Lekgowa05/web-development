// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>


<?php
include 'DBConn.php';

$id = $_GET['id'];

$conn->query("DELETE FROM User WHERE UserID=$id");



header("Location: adminDashboard.php");
?>
