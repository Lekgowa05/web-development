//navigation links
<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="addProduct.php">Add Product</a> |
<a href="manageUsers.php">Manage Users</a> |
<a href="logout.php">Logout</a>
</div>

<?php

session_start();

include 'DBConn.php';

if(!isset($_SESSION['admin']))
{
    header("Location: adminLogin.php");
    exit();
}

$result = $conn->query(
"SELECT * FROM Product");

?>

<h2>Manage Clothing Items</h2>

<a href="addProduct.php">
    Add New Clothing Item
</a>

<br><br>

<table border="1">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Quantity</th>
    <th>Actions</th>
</tr>
<?php while($row = $result->fetch_assoc()) { ?>
<tr>

<td><?php echo $row['ProductID']; ?></td>
<td><?php echo $row['ProductName']; ?></td>
<td>R<?php echo $row['Price']; ?></td>
<td><?php echo $row['Quantity']; ?></td>
<td>

<a href="editProduct.php?id=<?php echo $row['ProductID']; ?>">
Edit
</a>

|

<a href="deleteProduct.php?id=<?php echo $row['ProductID']; ?>"
onclick="return confirm('Delete this item?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</table>