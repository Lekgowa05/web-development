<div>
<a href="dashboard.php">Dashboard</a> |
<a href="products.php">Products</a> |
<a href="sellClothing.php">Sell Clothing</a> |
<a href="logout.php">Logout</a>
</div>

<?php

session_start();
include 'DBConn.php';
$userID =
$_SESSION['user']['UserID'];

$result =
$conn->query(

"SELECT *
 FROM Communication
 WHERE ReceiverID='$userID'
 ORDER BY DateSent DESC"
)
;
?>
<h2>Inbox</h2>
<table border="1">
<tr>
<th>Subject</th>
<th>Message</th>
<th>Date</th>
</tr>
<?php while($row =
$result->fetch_assoc()) { ?>

<tr>
<td>
<?php echo $row['Subject']; ?>
</td>
<td>
<?php echo $row['Message']; ?>
</td>
<td>
<?php echo $row['DateSent']; ?>
</td>
</tr>
<?php } ?>
</table>