//links
<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="manageProducts.php">Manage Products</a> |
<a href="logout.php">Logout</a>
</div>

<?php
session_start();
include 'DBConn.php';
$result =
$conn->query(

"SELECT *
 FROM Seller_Request
 WHERE Status='Pending'"
);
?>
<h2>Pending Clothing Requests</h2>
<table border="1">
<tr>
<th>ID</th>
<th>Product</th>
<th>Brand</th>
<th>Price</th>
<th>Image</th>
<th>Action</th>
</tr>
<?php while($row =
$result->fetch_assoc()) { ?>

<tr>
<td><?php echo $row['RequestID']; ?></td>
<td><?php echo $row['ProductName']; ?></td>
<td><?php echo $row['Brand']; ?></td>
<td>R<?php echo $row['Price']; ?></td>
<td>

<img
src="uploads/<?php echo $row['Image']; ?>"
width="100">

</td>
<td>

<a href="approveRequest.php?id=<?php
echo $row['RequestID']; ?>">

Approve
</a>
|
<a href="rejectRequest.php?id=<?php
echo $row['RequestID']; ?>">
Reject
</a>
</td>
</tr>
<?php } ?>
</table>