<?php
session_start();

include 'DBConn.php';
// Capture review information
$productID = $_POST['productID'];

$buyerID =
$_SESSION['user']['UserID'];

$rating = $_POST['rating'];

$review = $_POST['review'];

// Save review to database
$conn->query(

"INSERT INTO ProductReview

(ProductID, BuyerID, Rating, Review)

VALUES
('$productID',
 '$buyerID',
 '$rating',
 '$review')
");

header("Location: productDetails.php?id=$productID");
exit();
?>