// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>


<?php
// Include database connection
include 'DBConn.php';

// Delete table if it exists
$conn->query("DROP TABLE IF EXISTS User");

// Create User table
$conn->query("CREATE TABLE User (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100),
    Email VARCHAR(100),
    Password VARCHAR(255),
    PhoneNumber VARCHAR(15),
    Address TEXT,
    Role VARCHAR(20),
    AccountStatus VARCHAR(20) DEFAULT 'Active'
)");

//products table
// MODIFIED: Added fields needed for filtering
$conn->query("CREATE TABLE IF NOT EXISTS Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100),
    Description TEXT,
    Price DECIMAL(10,2),
    Category VARCHAR(50),
    Gender VARCHAR(20),
    Brand VARCHAR(50),
    Size VARCHAR(20),
    Quantity INT,
    Image VARCHAR(255),
    DateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Status VARCHAR(20) DEFAULT 'Available'
)");


//  Seller clothing request table

$conn->query("CREATE TABLE IF NOT EXISTS Seller_Request (
    RequestID INT AUTO_INCREMENT PRIMARY KEY,
    SellerID INT,
    ProductName VARCHAR(100),
    Brand VARCHAR(100),
    Description TEXT,
    Size VARCHAR(20),
    Price DECIMAL(10,2),
    Image VARCHAR(255),
    Status VARCHAR(20) DEFAULT 'Pending',
    RequestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SellerID)
    REFERENCES User(UserID)
)");

//  Communication table
$conn->query("CREATE TABLE IF NOT EXISTS Communication (
    CommunicationID INT AUTO_INCREMENT PRIMARY KEY,
    SenderID INT,
    ReceiverID INT,
    Subject VARCHAR(100),
    Message TEXT,
    DateSent TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Status VARCHAR(20) DEFAULT 'Unread',
    FOREIGN KEY (SenderID)
    REFERENCES User(UserID),
    FOREIGN KEY (ReceiverID)
    REFERENCES User(UserID)
)");

// Order verification table
$conn->query("CREATE TABLE IF NOT EXISTS OrderVerification (
    VerificationID INT AUTO_INCREMENT PRIMARY KEY,
    BuyerID INT,
    SellerID INT,
    ProductID INT,
    AdminID INT,
    ConditionVerified VARCHAR(20),
    DeliveryVerified VARCHAR(20),
    VerificationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Notes TEXT,
    FOREIGN KEY (BuyerID)
    REFERENCES User(UserID),
    FOREIGN KEY (SellerID)
    REFERENCES User(UserID),
    FOREIGN KEY (ProductID)
    REFERENCES Product(ProductID),
    FOREIGN KEY (AdminID)
    REFERENCES User(UserID)
)");

// table that Stores reviews and ratings for products
$conn->query("CREATE TABLE IF NOT EXISTS ProductReview (
    ReviewID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT NOT NULL,
    BuyerID INT NOT NULL,
    Rating INT NOT NULL,
    Review TEXT,
    ReviewDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ProductID)
    REFERENCES Product(ProductID),
    FOREIGN KEY (BuyerID)
    REFERENCES User(UserID)
)");

// Stores reviews and ratings for sellers
$conn->query("CREATE TABLE IF NOT EXISTS SellerReview (
    SellerReviewID INT AUTO_INCREMENT PRIMARY KEY,
    SellerID INT NOT NULL,
    BuyerID INT NOT NULL,
    Rating INT NOT NULL,
    Review TEXT,
    ReviewDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SellerID)
    REFERENCES User(UserID),
    FOREIGN KEY (BuyerID)
    REFERENCES User(UserID)
)");

// Open text file
$file = fopen("userData.txt", "r");

// Read file line by line
while (($line = fgets($file)) !== false) {

    // Split values by comma
    $data = explode(",", trim($line));

    // Assign values
    $name = $data[0];
    $email = $data[1];
    $password = $data[2];
    $phone = $data[3];
    $address = $data[4];
    $role = $data[5];

    // Insert into database
    $conn->query("INSERT INTO User 
    (FullName, Email, Password, PhoneNumber, Address, Role)
    VALUES ('$name','$email','$password','$phone','$address','$role')");
}

fclose($file);

echo "Table created and data inserted!";
?>
