<?php

session_start();
include 'DBConn.php';

// Ensure customer is logged in
if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit();
}

// Check if cart is empty
if(!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0)
{
    echo "<h2>Your shopping cart is empty.</h2>";
    echo "<a href='products.php'>Continue Shopping</a>";
    exit();
}

// Calculate total
$total = 0;

foreach($_SESSION['cart'] as $productID => $quantity)
{
    $result = $conn->query(
    "SELECT * FROM Product
     WHERE ProductID = $productID");

    if($result->num_rows > 0)
    {
        $product = $result->fetch_assoc();

        $total += ($product['Price'] * $quantity);
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
</head>
<body>

// navigation links

<div>
<a href="dashboard.php">Dashboard</a> |
<a href="products.php">Products</a> |
<a href="cart.php">Back To Cart</a> |
<a href="logout.php">Logout</a>
</div>
<hr>
<h2>Checkout</h2>
<h3>Order Summary</h3>
<p>
Total Amount:
<strong>R<?php echo number_format($total, 2); ?></strong>
</p>
<form method="POST" action="placeOrder.php">

    <h3>Delivery Information</h3>
    Full Name:

    <input
    type="text"
    name="fullName"
    required>
    <br><br>
    Phone Number:
    <input
    type="text"
    name="phone"
    required>
    <br><br>

    Delivery Address:

    <textarea
    name="address"
    required></textarea>
    <br><br>
    <button type="submit">
        Place Order
    </button>
</form>
</body>
</html>