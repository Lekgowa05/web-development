
<?php

session_start();

//Loop through all quantity fields
foreach($_POST['quantity']
as $productID => $quantity)
{//    Prevent invalid quantities
    
    if($quantity > 0)
    {
        $_SESSION['cart'][$productID]
        = $quantity;
    }
}
header("Location: cart.php");
exit();

?>