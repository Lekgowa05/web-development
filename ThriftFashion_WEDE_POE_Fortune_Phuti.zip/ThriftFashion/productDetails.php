
<h3>Customer Reviews</h3>
<?php

session_start();
include 'DBConn.php';
// Get product ID from URL
if(isset($_GET['id']))
{
    $productID = $_GET['id'];
}
else
{
    die("Product not found.");
}

$result = $conn->query(
"SELECT *
 FROM Product
 WHERE ProductID = '$productID'"
);
$product = $result->fetch_assoc();


$reviews =
$conn->query(

"SELECT *
 FROM ProductReview
 WHERE ProductID='$productID'
 ORDER BY ReviewDate DESC"
);

while($row =
$reviews->fetch_assoc())
{
echo "<div>";
echo "<strong>";
echo $row['Rating'];
echo "/5 Stars";
echo "</strong><br>";
echo $row['Review'];
echo "<hr>";
echo "</div>";
}
?>