
<?php
session_start();
include 'DBConn.php';

$sellerID =
$_POST['sellerID'];

$buyerID =
$_SESSION['user']['UserID'];

$rating =
$_POST['rating'];

$review =
$_POST['review'];

// Save seller review
$conn->query(

"INSERT INTO SellerReview
(SellerID, BuyerID, Rating, Review)
VALUES
('$sellerID',
 '$buyerID',
 '$rating',
 '$review')
");
header("Location: sellerProfile.php?id=$sellerID");

exit();
?>