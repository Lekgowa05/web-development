
<?php

session_start();
include 'DBConn.php';
$sellerID =
$_SESSION['user']['UserID'];

$productName =
$_POST['productName'];

$brand =
$_POST['brand'];

$description =
$_POST['description'];

$size =
$_POST['size'];

$price =
$_POST['price'];

// Image upload processing
$imageName =
time() . "_" .
$_FILES['image']['name'];

$target =
"uploads/" . $imageName;

move_uploaded_file(
$_FILES['image']['tmp_name'],
$target
);

// Save request
$sql = "

INSERT INTO Seller_Request
(
SellerID,
ProductName,
Brand,
Description,
Size,
Price,
Image
)

VALUES
(
'$sellerID',
'$productName',
'$brand',
'$description',
'$size',
'$price',
'$imageName'
)

";
$conn->query($sql);

echo "
Request submitted successfully.
waiting foer administrator approval.
";

?>