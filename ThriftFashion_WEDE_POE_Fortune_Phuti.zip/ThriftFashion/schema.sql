-- Create Database
CREATE DATABASE IF NOT EXISTS ClothingStore;
USE ClothingStore;

-- 1. User Table
CREATE TABLE User (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(15),
    Address TEXT,
    Role ENUM('Buyer','Seller','Admin') NOT NULL,
    DateRegistered DATETIME DEFAULT CURRENT_TIMESTAMP,
    AccountStatus ENUM('Active','Suspended','Banned') DEFAULT 'Active'
);

-- 2. Product Table
CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Title VARCHAR(100),
    Description TEXT,
    Category VARCHAR(50),
    Brand VARCHAR(50),
    Size VARCHAR(10),
    ConditionStatus VARCHAR(50),
    Price DECIMAL(10,2),
    ImageURL TEXT,
    Status ENUM('Available','Sold','Pending') DEFAULT 'Available',
    DatePosted DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (UserID) REFERENCES User(UserID)
        ON DELETE CASCADE
);

-- 3. Order Table
CREATE TABLE Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    BuyerID INT,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(10,2),
    OrderStatus ENUM('Pending','Shipped','Delivered') DEFAULT 'Pending',

    FOREIGN KEY (BuyerID) REFERENCES User(UserID)
        ON DELETE CASCADE
);

-- 4. OrderItem Table
CREATE TABLE OrderItem (
    OrderItemID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT DEFAULT 1,

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
        ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
        ON DELETE CASCADE
);

-- 5. Payment Table
CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    PaymentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    Amount DECIMAL(10,2),
    PaymentMethod VARCHAR(50),
    PaymentStatus ENUM('Pending','Completed','Failed') DEFAULT 'Pending',

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
        ON DELETE CASCADE
);

-- 6. Review Table
CREATE TABLE Review (
    ReviewID INT AUTO_INCREMENT PRIMARY KEY,
    BuyerID INT,
    SellerID INT,
    Rating INT CHECK (Rating BETWEEN 1 AND 5),
    Comment TEXT,
    ReviewDate DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (BuyerID) REFERENCES User(UserID)
        ON DELETE CASCADE,
    FOREIGN KEY (SellerID) REFERENCES User(UserID)
        ON DELETE CASCADE
);

-- 7. Authentication Table
CREATE TABLE Authentication (
    AuthID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT,
    VerificationStatus ENUM('Verified','Rejected','Pending') DEFAULT 'Pending',
    VerifiedBy INT,
    VerificationDate DATETIME,

    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
        ON DELETE CASCADE,
    FOREIGN KEY (VerifiedBy) REFERENCES User(UserID)
        ON DELETE SET NULL
);
