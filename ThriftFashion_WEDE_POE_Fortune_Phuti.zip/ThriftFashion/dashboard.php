// Page Navigation
<div>
<a href="dashboard.php">Dashboard</a> |
<a href="products.php">Browse Products</a> |
<a href="cart.php">Shopping Cart</a> |
<a href="sellClothing.php">Sell Clothing</a> |
<a href="inbox.php">Messages</a> |
<a href="logout.php">Logout</a>
</div>

<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h2>Welcome <?php echo $user['FullName']; ?></h2>

<a href="products.php">
    Browse Products
</a>

<table border="1">
    <tr>
        <?php foreach ($user as $key => $value) { ?>
            <th><?php echo $key; ?></th>
        <?php } ?>
    </tr>
    <tr>
        <?php foreach ($user as $value) { ?>
            <td><?php echo $value; ?></td>
        <?php } ?>
    </tr>
</table>

</body>
</html>
