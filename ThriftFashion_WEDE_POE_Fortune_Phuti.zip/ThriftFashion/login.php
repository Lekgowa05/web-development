// Page Navigation
<div>
<a href="login.php">Login</a> |
<a href="register.php">Register</a> |
<a href="adminLogin.php">Admin Login</a>
</div>

<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Login</h2>

<form method="POST" action="loginProcess.php">
    Email: <input type="email" name="email" required 
    value="<?php echo $_SESSION['email'] ?? ''; ?>"><br><br>

    Password: <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
</form>

<p style="color:red;">
<?php
if (isset($_SESSION['error'])) {
    echo $_SESSION['error'];
    unset($_SESSION['error']);
}
?>
</p>

<a href="register.php">Register</a>

</body>
</html>
