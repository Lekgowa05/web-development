<?php
session_start(); 
include 'DBConn.php';

// Ensure only admins can create users
if(!isset($_SESSION['admin'])) {
    header("Location: adminLogin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $role = $_POST['role'];

    $conn->query("INSERT INTO User (FullName, Email, Password, Role, AccountStatus)
                  VALUES ('$name','$email','$password','$role','Active')");
    
    $_SESSION['success'] = "User added successfully";
    header("Location: adminDashboard.php");
    exit();
}
?>
<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="manageUsers.php">Back To Users</a> |
<a href="logout.php">Logout</a>
</div>

<hr>

<form method="POST">
    Name: <input type="text" name="name" required><br>
    Email: <input type="email" name="email" required><br>
    Password: <input type="password" name="password" required><br>
    Role:
    <select name="role">
        <option>Buyer</option>
        <option>Seller</option>
        <option>Admin</option>
    </select><br>
    <button type="submit">Add</button>
</form>
