

<?php

session_start();

include 'DBConn.php';

$id = $_GET['id'];

//  Delete selected product

$conn->query(
"DELETE FROM Product
 WHERE ProductID=$id");

header("Location: manageProducts.php");
exit();

?>