

<?php

session_start();

//  Product removal from the cart

$id = $_GET['id'];

if(isset($_SESSION['cart'][$id])) {
    unset($_SESSION['cart'][$id]);
}

header("Location: cart.php");
exit();

?>