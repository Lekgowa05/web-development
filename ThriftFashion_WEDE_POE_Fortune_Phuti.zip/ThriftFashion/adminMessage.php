<?php
session_start();
include 'DBConn.php';

if(!isset($_SESSION['admin']))
{
    header("Location: adminLogin.php");
    exit();
}

$users = $conn->query("SELECT UserID, FullName FROM User");
$message_status = "";

if(isset($_POST['send']))
{
    $senderID = $_SESSION['admin']['UserID'];
    $receiverID = $_POST['receiver'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $conn->query(
    "INSERT INTO Communication
    (
        SenderID,
        ReceiverID,
        Subject,
        Message
    )
    VALUES
    (
        '$senderID',
        '$receiverID',
        '$subject',
        '$message'
    )");

    $message_status = "Message sent successfully.";
}
?>
<div>
<a href="adminDashboard.php">Dashboard</a> |
<a href="verifyOrder.php">Verify Orders</a> |
<a href="logout.php">Logout</a>
</div>

<h2>Send Message</h2>
<?php if(!empty($message_status)) { echo "<p style='color:green;'>$message_status</p>"; } ?>

<form method="POST">
Recipient:
<select name="receiver">
<?php while($user = $users->fetch_assoc()) { ?>
<option value="<?php echo $user['UserID']; ?>">
    <?php echo $user['FullName']; ?>
</option>
<?php } ?>
</select>
<br><br>
Subject:
<input type="text" name="subject" required>
<br><br>
Message:
<textarea name="message" required></textarea>
<br><br>
<button type="submit" name="send">
Send Message
</button>
</form>
