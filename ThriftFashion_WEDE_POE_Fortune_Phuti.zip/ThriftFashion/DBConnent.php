<?php
//db connection

$host = "localhost";
$username = "root";
$password = "";
$database = "ThriftFashion";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error){
    die("the connection has failed: " . $conn->connect_error);
}
?>
