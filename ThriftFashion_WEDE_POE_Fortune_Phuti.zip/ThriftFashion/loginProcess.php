// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>

<?php
session_start();
include 'DBConn.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Store email for sticky form
$_SESSION['email'] = $email;

// Get user from DB
$sql = "SELECT * FROM User WHERE Email='$email'";
$result = $conn->query($sql);

//validation
if(empty($email) || empty($password))
{
    $_SESSION['error'] = "All fields required";
    header("Location: login.php");
    exit();
}

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Compare hashed password (MD5 used in your data)
    if (md5($password) == $user['Password']) {

        // Check if account is verified
        if ($user['AccountStatus'] != 'Active') {
            $_SESSION['error'] = "Account pending admin approval.";
            header("Location: login.php");
            exit();
        }

        // Login success
        $_SESSION['user'] = $user;

        header("Location: dashboard.php");
    } else {
        $_SESSION['error'] = "Wrong password enterered";
        header("Location: login.php");
    }

} else {
    $_SESSION['error'] = "User does not exist. Please register.";
    header("Location: login.php");
}

$conn->close();
?>
