// Page Navigation
<div>
<a href="login.php">Home</a> |
<a href="register.php">Register</a> |
<a href="dashboard.php">Dashboard</a> |
<a href="adminLogin.php">Admin Login</a> |
<a href="logout.php">Logout</a>
</div>


<?php
// Database connection file

$host = "localhost";
$username = "root";
$password = "";
$database = "ClothingStore";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check if connection works
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
